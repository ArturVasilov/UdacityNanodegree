package arturvasilov.udacity.nanodegree.popularmovies.view;

/**
 * @author Artur Vasilov
 */
public interface LoadingView {

    void showLoading();

    void hideLoading();

    void showError();

}
