package com.udacity.gradle.builditbigger;

import android.support.annotation.NonNull;
import android.view.View;

/**
 * @author Artur Vasilov
 */
public final class AdsUtils {

    private AdsUtils() {
    }

    public static void showAds(@SuppressWarnings("UnusedParameters") @NonNull View view) {
        //Do nothing
    }

}
